public class Doctor extends Person{
    private final long doctorID;
    private final String specialisation;

    Doctor(long doctorID, String specialisation, String name, String surname, String birth, long ID){
        super(name,surname,birth,ID);
        this.doctorID = doctorID;
        this.specialisation = specialisation;
    }

    public long getDoctorID(){ return doctorID;}
    public String getSpecialisation(){ return specialisation;}



    public void examination(Patient patient){
        for (Anamnesis anamnes : patient.getAnamnesis()){
            if(anamnes.getDiagnosis().equals("coronavirus")){
                patient.getMedicine().add(new Medicine("death",10000));
            }
            if(anamnes.getDiagnosis().equals("diabetes")){
                patient.getMedicine().add(new Medicine("insulin", 10));
            }
            if(anamnes.getDiagnosis().equals("cancer")){
                patient.getMedicine().add(new Medicine("painkillers", 20));
                patient.getMedicine().add(new Medicine("chemical therapy", 50));
            }
            if(anamnes.getDiagnosis().equals("Turret syndrome")){
                patient.getMedicine().add(new Medicine("chills", 70));
            }
            if(anamnes.getDiagnosis().equals("amputation")){
                patient.getMedicine().add(new Medicine("prosthesis", 1));
            }
            else{
                System.out.println("it is fine");
            }
        }

    }

    @Override
    public String toString() {
        return "Doctor{" + "name = " + getName() +
                ", surname = " + getSurname() +
                ", id of doctor = " + doctorID +
                ", doctorID=" + doctorID +
                ", specialisation='" + specialisation + '\'' +
                '}';
    }
}
