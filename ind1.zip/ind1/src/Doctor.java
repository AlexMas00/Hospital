public class Doctor extends Person{
    private final long doctorID;
    private final String specialisation;

    Doctor(long doctorID, String specialisation, String name, String surname, String birth, long ID){
        super(name,surname,birth,ID);
        this.doctorID = doctorID;
        this.specialisation = specialisation;
    }

    public long getDoctorID(){ return doctorID;}
    public String getSpecialisation(){ return specialisation;}



    public void examination(Patient patient){
        for (Anamnesis anamnes : patient.getAnamnesis()){
            if(anamnes.getDiagnosis().equals("coronavirus")){
                patient.getMedicine().add(new Medicine("death",10000));
                patient.changeStatus("Quarantined");
            }
            if(anamnes.getDiagnosis().equals("diabetes")){
                patient.getMedicine().add(new Medicine("insulin", 10));
                patient.changeStatus("disabled");
            }
            if(anamnes.getDiagnosis().equals("cancer")){
                patient.getMedicine().add(new Medicine("painkillers", 20));
                patient.getMedicine().add(new Medicine("chemical therapy", 50));
            }
            if(anamnes.getDiagnosis().equals("Turret syndrome")){
                patient.add_medicine(new Medicine("chills", 70));
                patient.changeStatus("disabled");
            }
            if(anamnes.getDiagnosis().equals("amputation")){
                patient.add_medicine(new Medicine("prosthesis", 1));
                patient.changeStatus("disabled");

            }

        }
        if(patient.getAnamnesis().isEmpty()){
            System.out.println("it's fine");
        }

    }

    @Override
    public String toString() {
        return "Doctor{" + "name = " + getName() +
                ", surname = " + getSurname() +
                ", id of person = " + getId() +
                ", doctorID=" + doctorID +
                ", specialisation='" + specialisation + '\'' +
                '}';
    }
}
