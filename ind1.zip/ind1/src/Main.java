import java.util.Set;

public class Main {
    public static void main(String[] args) {

        Hospital hospital = new Hospital();
        Doctor doctor1 = new Doctor(20345, "cardiologist", "Will", "Smith", "1979", 11122342);
        Doctor doctor2 = new Doctor(94056, "pediatrician", "Bill", "Carter", "1964", 1123422);
        Doctor doctor3 = new Doctor(56324, "oncologist", "Chung", "Lee", "1971", 11245321);

        hospital.doctors.add(doctor1);
        hospital.doctors.add(doctor2);
        hospital.doctors.add(doctor3);

        hospital.printDoctors();
        Patient patient1 = new Patient("alive", "Edgar", "Po", "1986", 11123973);
        Patient patient2 = new Patient("alive", "Alan", "Shir", "1998", 11126875);
        Patient patient3 = new Patient("alive", "Moo", "Scott", "1955", 11123456);
        Patient patient4 = new Patient("alive", "Carl", "Butt", "1970", 11123452);
        Patient patient5 = new Patient("alive", "Fisk", "Push", "2001", 11123577);//добавить анамнез и лек


        hospital.patients.add(patient1);
        hospital.patients.add(patient2);
        hospital.patients.add(patient3);
        hospital.patients.add(patient4);
        hospital.patients.add(patient5);

        hospital.printPatients();

        System.out.println("");

    }

    //добавить мейн
}
