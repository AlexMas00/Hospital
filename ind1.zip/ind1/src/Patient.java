import java.util.HashSet;
import java.util.Set;

public class Patient extends Person{

    private Set<Medicine> medicines = new HashSet<Medicine>();
    private Set<Anamnesis> anamnesis = new HashSet<Anamnesis>();
    private String status;

    Patient(String status, String name, String surname, String birth, long ID){
        super(name, surname, birth, ID);
        this.status = status;

    }

    public Set<Anamnesis> getAnamnesis(){ return anamnesis;}
    public Set<Medicine> getMedicine(){ return medicines;}

    public void changeStatus(String status){ this.status = status; }

    // метод гетанамнез и гетмедесин

    public void add_medicine(Medicine medicine){
        medicines.add(medicine);
    }
    public void remove_medicine(Medicine medicine){
        medicines.remove(medicine);
    }

    public void add_anamnesis(Anamnesis anamnesis){
        this.anamnesis.add(anamnesis);
    }

    public String getStatus(){ return status; }

    @Override
    public String toString() {
        return "Patient{ " + "name = " + getName() +
                ", surname = " + getSurname() +
                ", id = " + getId() +
                ", medicines = " + medicines +
                ", anamnesis = " + anamnesis +
                ", status = '" + status + '\'' +
                '}';
    }

    // метод get status

}
