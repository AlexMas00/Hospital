public class Medicine {
    private final String title;
    private final int amount;

    Medicine(String title, int amount){
        this.title = title;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Medicine{" +
                "title = '" + title + '\'' +
                ", amount = " + amount +
                '}';
    }
}
