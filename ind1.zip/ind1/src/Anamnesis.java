public class Anamnesis {
    private final String diagnosis;//диабет(инсулин),ампутация ноги(костыль),
    // 2 стадия рака(химиотерапия,обезбол), ДЦП(коляска) , коронавирус(press F)
    private final String data;

    Anamnesis(String diagnosis, String data){
        this.diagnosis = diagnosis;
        this.data = data;
    }

    public String getDiagnosis(){ return diagnosis; }
    public String getData(){ return data; }

    @Override
    public String toString() {
        return "Anamnesis{" +
                "diagnosis = '" + diagnosis + '\'' +
                ", data = '" + data + '\'' +
                '}';
    }
}
