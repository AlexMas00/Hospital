import java.util.HashSet;
import java.util.Set;

public class Hospital {
    Set<Patient> patients = new HashSet<Patient>();// исп сет вместо массива ибо не знаем сколько
    Set<Doctor> doctors = new HashSet<Doctor>();//будет пациентов(докторов) и порядок не важен

    public void write_out(Patient patient){
        patients.remove(patient);
        System.out.println("Patient"+ patient + "has been removed");
    }

    public void add_patient(Patient patient){
        patients.add(patient);
        System.out.println("Patient"+ patient + "has been add");

    }

    public void add_doctor(Doctor doctor){
        doctors.add(doctor);
        System.out.println("Doctor" + doctor + "has been added");

    }

    public void fire_doctor(Doctor doctor){
        doctors.remove(doctor);
        System.out.println("Doctor" + doctor + "has been fired");

    }

    public Patient search_of_patient(long ID){
        for(Patient patient : patients){
            if(ID == patient.getId()) {
                return patient;
            }
        }

        return null;
    }

    public Doctor search_of_doctor(long doctorID){
        for(Doctor doctor : doctors){
            if(doctorID == doctor.getDoctorID()) {
                return doctor;
            }
        }
        return null;
    }

    public Doctor search_of_specialist(String specialisation){
        for(Doctor doctor : doctors){
            if(specialisation.equals(doctor.getSpecialisation())){
                return doctor;
            }
        }
        return null;
    }

    public void printDoctors(){
        for(Doctor doctor : doctors){
            System.out.println(doctor);
        }

    }

    public void printPatients(){
        for(Patient patient : patients){
            System.out.println(patient);
        }

    }



    // добавить/уволить врача,поиск пациентов и докторов по ID,поиск специалиста




}
