public class Person {

    private final String name;
    private final String surname;
    private final String birth;
    private final long ID;


    Person(String name, String surname, String birth, long ID)
    {
        this.name = name;
        this.surname = surname;
        this.birth = birth;
        this.ID = ID;
    }

    public String getName(){ return name;}
    public String getSurname(){ return surname;}
    public String getBirth(){ return birth;}
    public long getId(){ return ID;}





}
